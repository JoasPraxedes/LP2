﻿namespace PContato004
{
    partial class frmSobre
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmSobre));
            this.pc_Grupo = new System.Windows.Forms.PictureBox();
            this.pc_Dave = new System.Windows.Forms.PictureBox();
            this.pc_Carina = new System.Windows.Forms.PictureBox();
            this.pc_Carlos = new System.Windows.Forms.PictureBox();
            this.pc_Vitor = new System.Windows.Forms.PictureBox();
            this.pc_Joas = new System.Windows.Forms.PictureBox();
            this.pc_Qrcode = new System.Windows.Forms.PictureBox();
            this.rtb_Sobre = new System.Windows.Forms.RichTextBox();
            ((System.ComponentModel.ISupportInitialize)(this.pc_Grupo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pc_Dave)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pc_Carina)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pc_Carlos)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pc_Vitor)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pc_Joas)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pc_Qrcode)).BeginInit();
            this.SuspendLayout();
            // 
            // pc_Grupo
            // 
            this.pc_Grupo.Image = ((System.Drawing.Image)(resources.GetObject("pc_Grupo.Image")));
            this.pc_Grupo.Location = new System.Drawing.Point(0, 0);
            this.pc_Grupo.Name = "pc_Grupo";
            this.pc_Grupo.Size = new System.Drawing.Size(632, 364);
            this.pc_Grupo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pc_Grupo.TabIndex = 0;
            this.pc_Grupo.TabStop = false;
            // 
            // pc_Dave
            // 
            this.pc_Dave.Image = ((System.Drawing.Image)(resources.GetObject("pc_Dave.Image")));
            this.pc_Dave.Location = new System.Drawing.Point(12, 370);
            this.pc_Dave.Name = "pc_Dave";
            this.pc_Dave.Size = new System.Drawing.Size(108, 77);
            this.pc_Dave.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pc_Dave.TabIndex = 1;
            this.pc_Dave.TabStop = false;
            // 
            // pc_Carina
            // 
            this.pc_Carina.Image = ((System.Drawing.Image)(resources.GetObject("pc_Carina.Image")));
            this.pc_Carina.Location = new System.Drawing.Point(136, 370);
            this.pc_Carina.Name = "pc_Carina";
            this.pc_Carina.Size = new System.Drawing.Size(108, 77);
            this.pc_Carina.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pc_Carina.TabIndex = 1;
            this.pc_Carina.TabStop = false;
            // 
            // pc_Carlos
            // 
            this.pc_Carlos.Image = ((System.Drawing.Image)(resources.GetObject("pc_Carlos.Image")));
            this.pc_Carlos.Location = new System.Drawing.Point(261, 370);
            this.pc_Carlos.Name = "pc_Carlos";
            this.pc_Carlos.Size = new System.Drawing.Size(108, 77);
            this.pc_Carlos.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pc_Carlos.TabIndex = 1;
            this.pc_Carlos.TabStop = false;
            // 
            // pc_Vitor
            // 
            this.pc_Vitor.Image = ((System.Drawing.Image)(resources.GetObject("pc_Vitor.Image")));
            this.pc_Vitor.InitialImage = null;
            this.pc_Vitor.Location = new System.Drawing.Point(524, 370);
            this.pc_Vitor.Name = "pc_Vitor";
            this.pc_Vitor.Size = new System.Drawing.Size(108, 77);
            this.pc_Vitor.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pc_Vitor.TabIndex = 1;
            this.pc_Vitor.TabStop = false;
            // 
            // pc_Joas
            // 
            this.pc_Joas.Image = ((System.Drawing.Image)(resources.GetObject("pc_Joas.Image")));
            this.pc_Joas.Location = new System.Drawing.Point(397, 370);
            this.pc_Joas.Name = "pc_Joas";
            this.pc_Joas.Size = new System.Drawing.Size(108, 77);
            this.pc_Joas.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pc_Joas.TabIndex = 1;
            this.pc_Joas.TabStop = false;
            // 
            // pc_Qrcode
            // 
            this.pc_Qrcode.Image = ((System.Drawing.Image)(resources.GetObject("pc_Qrcode.Image")));
            this.pc_Qrcode.InitialImage = null;
            this.pc_Qrcode.Location = new System.Drawing.Point(638, 38);
            this.pc_Qrcode.Name = "pc_Qrcode";
            this.pc_Qrcode.Size = new System.Drawing.Size(150, 114);
            this.pc_Qrcode.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pc_Qrcode.TabIndex = 1;
            this.pc_Qrcode.TabStop = false;
            // 
            // rtb_Sobre
            // 
            this.rtb_Sobre.Enabled = false;
            this.rtb_Sobre.Location = new System.Drawing.Point(638, 225);
            this.rtb_Sobre.Name = "rtb_Sobre";
            this.rtb_Sobre.Size = new System.Drawing.Size(150, 139);
            this.rtb_Sobre.TabIndex = 2;
            this.rtb_Sobre.Text = resources.GetString("rtb_Sobre.Text");
            // 
            // frmSobre
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.rtb_Sobre);
            this.Controls.Add(this.pc_Joas);
            this.Controls.Add(this.pc_Qrcode);
            this.Controls.Add(this.pc_Vitor);
            this.Controls.Add(this.pc_Carlos);
            this.Controls.Add(this.pc_Carina);
            this.Controls.Add(this.pc_Dave);
            this.Controls.Add(this.pc_Grupo);
            this.Name = "frmSobre";
            this.Text = "frmSobre";
            ((System.ComponentModel.ISupportInitialize)(this.pc_Grupo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pc_Dave)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pc_Carina)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pc_Carlos)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pc_Vitor)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pc_Joas)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pc_Qrcode)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox pc_Grupo;
        private System.Windows.Forms.PictureBox pc_Dave;
        private System.Windows.Forms.PictureBox pc_Carina;
        private System.Windows.Forms.PictureBox pc_Carlos;
        private System.Windows.Forms.PictureBox pc_Vitor;
        private System.Windows.Forms.PictureBox pc_Joas;
        private System.Windows.Forms.PictureBox pc_Qrcode;
        private System.Windows.Forms.RichTextBox rtb_Sobre;
    }
}