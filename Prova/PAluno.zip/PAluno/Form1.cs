﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PAluno
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void BtnExecutar_Click(object sender, EventArgs e)
        {
            double[,] nota = new double[6, 3];
            string notas;
            double mediaAluno = 0, mediaGeral = 0;
            int i, j;


            for (i = 0; i < 6; i++)
            {
                for (j = 0; j < 3; j++)
                {

                    notas = Interaction.InputBox("Aluno " + (i + 1).ToString() + " Nota Professor " + (j + 1).ToString(), "Entrada de Notas");

                    if (!double.TryParse(notas, out nota[i, j]))
                    {
                        MessageBox.Show("Nota Inválida");
                        j--;
                    }
                    else
                    {
                        if (!(nota[i, j] >= 0 && nota[i, j] <= 10)) //verificação se o usuário digitou algum número menor do que 0 ou maior do que 10
                        {
                            MessageBox.Show("Nota tem que ser entre 0 e 10");
                            j--;
                        }
                        else
                        {
                            while (nota[i, j] <= 0)
                            {
                                notas = "";
                                notas = Interaction.InputBox("Aluno " + (i + 1).ToString() + " Nota Professor " + (j + 1).ToString(), "Entrada de Notas");

                                if (!double.TryParse(notas, out nota[i, j]))
                                {
                                    MessageBox.Show("Nota Inválida");
                                }
                            }
                        }
                    }
                  //  lstbxAlunos.Items.Add(" " + (lin + 1).ToString() + ": " + (col + 1).ToString() + notas + " " + (col + 2).ToString() + notas);

                }
                lstbxAlunos.Items.Add("Aluno " + (i + 1).ToString() + ": " + (j + 1).ToString() + nota + " " + (j + 2).ToString() + nota);
                
            }
       

        }
    }
    
}
